#!/usr/bin/env python3
"""
Changelog Generator for moduli_generator project

This script generates a CHANGELOG.rst file from git commit history,
organizing commits by date in reStructuredText format.
"""

import subprocess
import re
from datetime import datetime
from collections import defaultdict
from pathlib import Path
import toml


class ChangelogGenerator:
    """
    Generates and handles changelog files for a project, utilizing git commit
    history and project metadata.

    This class provides functionalities to parse and categorize git commits,
    generate changelog content in reStructuredText (RST) format, and save it to a
    file. It also incorporates basic project information such as version,
    description, and authors from the project's configuration file.

    :ivar project_root: The root directory of the project where the changelog is to
        be generated.
    :type project_root: Path
    :ivar project_info: Parsed project metadata from pyproject.toml.
    :type project_info: dict
    """
    def __init__(self, project_root=None):
        """
        Initializes the class with a given project root directory and loads related
        project information. If no project root is provided, it defaults to the
        current working directory.

        :param project_root: The root directory of the project
        :type project_root: str or None
        """
        self.project_root = Path(project_root) if project_root else Path.cwd()
        self.project_info = self._load_project_info()

    def _load_project_info(self):
        """Load project information from pyproject.toml."""
        try:
            pyproject_path = self.project_root / "pyproject.toml"
            if pyproject_path.exists():
                with open(pyproject_path, 'r') as f:
                    data = toml.load(f)
                    return data.get('tool', {}).get('poetry', {})
        except Exception as e:
            print(f"Warning: Could not load pyproject.toml: {e}")

        return {}

    def _get_git_commits(self, max_commits=50):
        """Get git commit history with dates and messages."""
        try:
            # Get commit log with format: hash|date|author|message
            cmd = [
                'git', 'log',
                f'--max-count={max_commits}',
                '--pretty=format:%H|%ad|%an <%ae>|%s',
                '--date=short'
            ]

            result = subprocess.run(cmd, capture_output=True, text=True,
                                    cwd=self.project_root)

            if result.returncode != 0:
                raise RuntimeError(f"Git command failed: {result.stderr}")

            return result.stdout.strip().split('\n')

        except Exception as e:
            print(f"Error getting git commits: {e}")
            return []

    def _parse_commit_line(self, line):
        """Parse a single commit line into components."""
        try:
            parts = line.split('|', 3)
            if len(parts) != 4:
                return None

            hash_id, date_str, author, message = parts

            # Parse date
            commit_date = datetime.strptime(date_str, '%Y-%m-%d')

            return {
                'hash': hash_id,
                'date': commit_date,
                'author': author,
                'message': message.strip()
            }
        except Exception as e:
            print(f"Error parsing commit line '{line}': {e}")
            return None

    def _categorize_commit(self, message):
        """Categorize commit based on message content."""
        message_lower = message.lower()

        # Define categories and their keywords
        categories = {
            'Database Improvements': [
                'database', 'db', 'mariadb', 'connector', 'sql', 'schema',
                'transactional', 'parameterized'
            ],
            'Bug Fixes': [
                'fix', 'fixed', 'bug', 'error', 'issue', 'correct'
            ],
            'Features': [
                'add', 'added', 'new', 'feature', 'implement', 'create', 'created'
            ],
            'Refactoring': [
                'refactor', 'refactored', 'restructure', 'reorganize', 'cleanup'
            ],
            'Documentation': [
                'doc', 'documentation', 'readme', 'comment', 'docstring'
            ],
            'Configuration': [
                'config', 'configuration', 'settings', 'default', 'constants'
            ],
            'Testing': [
                'test', 'testing', 'tests', 'successful', 'complete'
            ],
            'Performance': [
                'performance', 'optimize', 'speed', 'efficiency'
            ],
            'Security': [
                'security', 'secure', 'vulnerability', 'auth'
            ]
        }

        # Check for category keywords
        for category, keywords in categories.items():
            if any(keyword in message_lower for keyword in keywords):
                return category

        # Check for specific patterns
        if 'checkpoint' in message_lower or 'milestone' in message_lower:
            return 'Milestones'

        if 'production' in message_lower or 'release' in message_lower:
            return 'Releases'

        return 'General'

    def _format_commit_message(self, message):
        """Format commit message for changelog."""
        # Remove common prefixes and clean up
        message = re.sub(r'^(feat|fix|docs|style|refactor|test|chore):\s*', '', message)

        # Capitalize first letter
        if message:
            message = message[0].upper() + message[1:]

        # Remove trailing periods and normalize
        message = message.rstrip('.')

        return message

    def _group_commits_by_date(self, commits):
        """Group commits by date."""
        grouped = defaultdict(list)

        for commit in commits:
            if commit:  # Skip None commits
                date_key = commit['date'].strftime('%Y-%m-%d')
                grouped[date_key].append(commit)

        return grouped

    def _generate_rst_header(self):
        """Generate the RST header section."""
        header = []
        header.append("=========")
        header.append("CHANGELOG")
        header.append("=========")
        header.append("")
        header.append("This document tracks the changes made to the moduli_generator project.")
        header.append("")

        # Add version info if available
        if self.project_info.get('version'):
            header.append(f"Version {self.project_info['version']}")
            header.append("=" * (8 + len(self.project_info['version'])))
            header.append("")

        return header

    def _generate_date_section(self, date_str, commits):
        """Generate RST section for a specific date."""
        section = []

        # Convert date string to readable format
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        formatted_date = date_obj.strftime('%Y-%m-%d')

        section.append(formatted_date)
        section.append("-" * len(formatted_date))
        section.append("")

        # Group commits by category
        categorized = defaultdict(list)
        for commit in commits:
            category = self._categorize_commit(commit['message'])
            categorized[category].append(commit)

        # Add commits by category
        for category in sorted(categorized.keys()):
            category_commits = categorized[category]

            if len(category_commits) == 1:
                # Single commit - format as bullet point with category
                commit = category_commits[0]
                formatted_msg = self._format_commit_message(commit['message'])
                section.append(f"* **{category}**: {formatted_msg}")
            else:
                # Multiple commits - create subsection
                section.append(f"**{category}**:")
                section.append("")
                for commit in category_commits:
                    formatted_msg = self._format_commit_message(commit['message'])
                    section.append(f"  * {formatted_msg}")
                section.append("")

        section.append("")
        return section

    def _generate_project_info_section(self):
        """Generate project information section."""
        section = []
        section.append("Project Information")
        section.append("==================")
        section.append("")

        info = self.project_info
        if info.get('name'):
            section.append(f"* **Project**: {info['name']}")
        if info.get('version'):
            section.append(f"* **Version**: {info['version']}")
        if info.get('description'):
            section.append(f"* **Description**: {info['description']}")
        if info.get('authors'):
            authors = info['authors']
            if isinstance(authors, list):
                section.append(f"* **Author**: {authors[0]}")
            else:
                section.append(f"* **Author**: {authors}")

        # Add URLs if available
        urls = info.get('urls', {})
        if urls.get('Repository'):
            section.append(f"* **Repository**: {urls['Repository']}")
        if urls.get('Homepage'):
            section.append(f"* **Homepage**: {urls['Homepage']}")

        section.append("* **License**: See LICENSE.rst")
        section.append("")

        return section

    def generate_changelog(self, output_file="CHANGELOG.rst", max_commits=50):
        """
        Generates a changelog file based on git commit history and saves it to the
        specified output file. The changelog is formatted in reStructuredText (RST)
        format and includes grouped commit entries by date in descending order.

        :param output_file: The name of the output changelog file with default
            value "CHANGELOG.rst".
        :type output_file: str, optional
        :param max_commits: The maximum number of recent commits to include in the
            changelog, with a default value of 50.
        :type max_commits: int, optional
        :return: None
        :rtype: None
        """
        print("Generating changelog...")

        # Get git commits
        commit_lines = self._get_git_commits(max_commits)
        if not commit_lines:
            print("No git commits found.")
            return

        # Parse commits
        commits = []
        for line in commit_lines:
            if line.strip():
                commit = self._parse_commit_line(line)
                if commit:
                    commits.append(commit)

        if not commits:
            print("No valid commits found.")
            return

        print(f"Found {len(commits)} commits")

        # Group by date
        grouped_commits = self._group_commits_by_date(commits)

        # Generate changelog content
        changelog_lines = []

        # Add header
        changelog_lines.extend(self._generate_rst_header())

        # Add date sections (most recent first)
        for date_str in sorted(grouped_commits.keys(), reverse=True):
            date_commits = grouped_commits[date_str]
            changelog_lines.extend(self._generate_date_section(date_str, date_commits))

        # Add project info section
        changelog_lines.extend(self._generate_project_info_section())

        # Write to file
        output_path = self.project_root / output_file
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(changelog_lines))

            print(f"Changelog written to {output_path}")
            print(f"Generated {len(grouped_commits)} date sections from {len(commits)} commits")

        except Exception as e:
            print(f"Error writing changelog: {e}")


def main():
    """Main entry point for the changelog generator."""
    import argparse

    parser = argparse.ArgumentParser(description='Generate CHANGELOG.rst from git history')
    parser.add_argument('--output', '-o', default='CHANGELOG.rst',
                        help='Output file name (default: CHANGELOG.rst)')
    parser.add_argument('--max-commits', '-m', type=int, default=50,
                        help='Maximum number of commits to process (default: 50)')
    parser.add_argument('--project-root', '-p',
                        help='Project root directory (default: current directory)')

    args = parser.parse_args()

    # Create generator and generate changelog
    generator = ChangelogGenerator(args.project_root)
    generator.generate_changelog(args.output, args.max_commits)


if __name__ == "__main__":
    main()